# app.py
import streamlit as st
import pandas as pd
import google.generativeai as genai
import time

# ------------------------------
# 1️⃣ Configure Generative AI API
# ------------------------------
genai.configure(api_key="AIzaSyDYRwLCkX6tUn_-Vj2LXKx9J91h1RjKSBE")  # Replace with your actual API key

# ------------------------------
# 2️⃣ Streamlit App UI
# ------------------------------
st.title("🛍️ Myntra Product Review Analyzer & Summarizer")
st.write("Upload your CSV file with columns: product_name, review_text, rating")

uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.success(f"Loaded {len(df)} reviews")
    st.dataframe(df.head())

    # ------------------------------
    # 3️⃣ Analyze Reviews Button
    # ------------------------------
    if st.button("Analyze Reviews"):
        st.info("🔹 Starting analysis. Please wait...")

        results = []
        model = genai.GenerativeModel("text-bison-002")  # ✅ Supported model

        for i, row in df.iterrows():
            prompt = f"""
            Analyze this Myntra product review:
            Review: "{row['review_text']}"
            Rating: {row['rating']}

            Provide:
            1. Sentiment (Positive / Negative / Neutral)
            2. Key points mentioned
            3. Whether customer would likely recommend this product
            """

            try:
                response = model.generate_content(prompt)
                analysis_text = response.text.strip()
            except Exception as e:
                analysis_text = f"Error: Could not analyze review. ({e})"

            results.append({
                "product_name": row["product_name"],
                "review": row["review_text"],
                "rating": row["rating"],
                "analysis": analysis_text
            })

            # Optional: small delay to avoid API limits
            time.sleep(0.5)

            st.write(f"✅ Processed review {i+1}/{len(df)}")

        result_df = pd.DataFrame(results)

        # ------------------------------
        # 4️⃣ Show results in Streamlit
        # ------------------------------
        st.success("🎉 Analysis Completed!")
        st.dataframe(result_df)

        # ------------------------------
        # 5️⃣ Allow CSV download
        # ------------------------------
        csv = result_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Analysis CSV",
            data=csv,
            file_name="myntra_review_analysis.csv",
            mime="text/csv"
        )
